import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.css']
})
export class EmployeeDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  onclick(id:number, name : String, Salary : number, Department : String){
    alert(id + " " + name +" " + Salary + " " + Department);
  }
}
