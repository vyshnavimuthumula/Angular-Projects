export interface Hero {
}
