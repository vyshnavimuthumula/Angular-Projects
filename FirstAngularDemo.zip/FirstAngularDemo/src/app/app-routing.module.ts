import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WelcomeComponent } from './product/welcome/welcome.component';

// import {WelcomeComponent} from './welcome/welcome.component';

import { ProductDetailsComponent } from './product/product-details/product-details.component';
import { ProductListComponent } from './product/product-list/product-list.component';
const routes: Routes = [
  {
    path:'welcome',
    component:WelcomeComponent
  },
  {
    path:'products',
    component:ProductListComponent
  },
  {
    path:'',
    redirectTo:'welcome',
    pathMatch:'full'
  },
  {
    path:'products/:id',
    component:ProductDetailsComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
