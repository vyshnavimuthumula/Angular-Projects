import { Component } from '@angular/core';

@Component({ //@ is decorator
  selector: 'app-root', //directive
  templateUrl: './app.component.html', //view
  styleUrls: ['./app.component.css']    //view design
})
export class AppComponent {
  title = 'dashboard';           //property
}
