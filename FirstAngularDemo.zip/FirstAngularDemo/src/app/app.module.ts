import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WelcomeComponent } from './product/welcome/welcome.component';
import { HeroListComponent } from './product/hero-list/hero-list.component';

import { ProductDetailsComponent } from './product/product-details/product-details.component';
import { StarComponent } from './product/star/star.component';
import { ProductFilterPipe } from './product/product-filter.pipe';
import {FormsModule} from '@angular/forms'
import {HttpClientModule} from '@angular/common/http';
import { ProductListComponent } from './product/product-list/product-list.component';
@NgModule({
  declarations: [
    AppComponent,
    //WelcomeComponent,
    HeroListComponent,
    ProductListComponent,
    ProductDetailsComponent,
    StarComponent,
    ProductFilterPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
