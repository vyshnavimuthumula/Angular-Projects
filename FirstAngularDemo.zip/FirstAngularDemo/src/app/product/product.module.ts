import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from '../app.component';
import { AppRoutingModule } from '../app-routing.module';
import { WelcomeComponent } from './welcome/welcome.component';
import { HeroListComponent } from './hero-list/hero-list.component';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { StarComponent } from './star/star.component';
import { ProductFilterPipe } from './product-filter.pipe';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
@NgModule({
declarations: [
  AppComponent,
  WelcomeComponent,
  HeroListComponent,
  ProductListComponent,
  ProductDetailsComponent,
  StarComponent,
  ProductFilterPipe

 ],
imports: [
BrowserModule,
AppRoutingModule,
FormsModule,
HttpClientModule
 ],
providers: [],
bootstrap: [AppComponent]//default component
})

export class ProductModule { }
