import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';

import {map} from 'rxjs/operators';
import { IproductInterface } from './iproduct';
// import { catchEroor} from '@angular/compiler/src/output/abstract_emitter';
@Injectable({
  providedIn: 'root'
})
export class ProductServiceService {

  constructor(private http:HttpClient) { }
  private productUrl='./assets/products.json';
  // getProducts():
  //   // Observable<IproductInterface[]>
  //   {
  //   return this.http.get<IproductInterface[]>(this.productUrl).pipe;
  //   catchError(this.handleError)
  // }
  getProducts():
    Observable<IproductInterface[]>{
    return this.http.get<IproductInterface[]>(this.productUrl);
   
  }
  getProduct(id:number):
  Observable<IproductInterface | undefined>{
  return this.getProducts().pipe(map((products:IproductInterface[])=>
          products.find(p=>p.productId === id)));
}
}