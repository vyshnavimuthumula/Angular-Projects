import { Component, OnInit } from '@angular/core';
import { IproductInterface } from '../iproduct';
import { ActivatedRoute } from '@angular/router';
import { ProductServiceService } from '../product-service.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {
errorMessage:string="";
product:IproductInterface;
id:string;
  constructor(private route:ActivatedRoute,private productService:ProductServiceService) { }


  ngOnInit() {
    const param = this.route.snapshot.paramMap.get('id'); //id is string taking from url
    if(param){
      const id=+param;  //converting into number
      console.log(typeof id); //gives type of id
      this.getProduct(id);
    }
  }
  getProduct(id){
    this.productService.getProduct(id).subscribe(
      product=>this.product=product
      // error =>this.errorMessage=<any>(error); 
    )
  }
}
