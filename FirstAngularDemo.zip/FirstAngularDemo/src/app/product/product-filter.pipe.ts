import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'productFilter'
})
export class ProductFilterPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    console.log(value);
    return value.filter((data)=>data.productName.indexOf(args)!==-1);
    
  }

}
