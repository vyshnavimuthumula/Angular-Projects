import { Component, OnInit } from '@angular/core';
import { IproductInterface } from 'src/app/product/iproduct';
import { ProductServiceService } from 'src/app/product/product-service.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  // private product-service:ProductServiceService
  constructor(private productService:ProductServiceService) { }
  products :IproductInterface[];
  productFilter: any;
  ngOnInit():void {
    // this.product=this.productService.getProducts();
    this.productService.getProducts().subscribe(products=>{
      this.products=products;
      this.productFilter = this.products;
      console.log(products);
    }
    );
  }
  public show:boolean = false;
  public buttonName:any = 'Hide Image';
  displayImageText = "visible";
  showImage(){
  this.show = !this.show;
  
  // CHANGE THE NAME OF THE BUTTON.
  if(this.show) 
  {this.buttonName = "Show Image";
  this.displayImageText = "hidden";}
  else
  {this.buttonName = "Hide Image";
  this.displayImageText = "visible";
  }
  
  }
  someMessage:string;
  onRatingClicked(message){
      this.someMessage=message;
  }
}
