import { Component, OnInit, Input, Output,EventEmitter } from '@angular/core';
// import { EventEmitter } from 'events';

@Component({
  selector: 'app-star',
  templateUrl: './star.component.html',
  styleUrls: ['./star.component.css']
})
export class StarComponent implements OnInit {
@Input() starRating:number;
@Output() RatingClicked:EventEmitter<string>=new EventEmitter<string>();
  starWidth: number;
  constructor() { }

  ngOnInit() {
  }
  ngOnChanges(){
    this.starWidth=this.starRating * 15;
    console.log(this.starWidth);
  }
  onClick(){
    // console.log("you are clicked product");
    this.RatingClicked.emit("You are clicked product " + this.starRating + " star");
  }
  
}
