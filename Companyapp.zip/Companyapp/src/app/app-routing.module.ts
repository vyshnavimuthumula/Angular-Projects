import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchFormComponent } from './search-form/search-form.component';
import { ProductListComponent } from './product-list/product-list.component';


const routes: Routes = [
  {
    path:'search',
    component: SearchFormComponent
  },
  {
    path:'products',
    component: ProductListComponent
  },
  {
    path:'',
    redirectTo: 'search',
    pathMatch:'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents = [SearchFormComponent,ProductListComponent]
