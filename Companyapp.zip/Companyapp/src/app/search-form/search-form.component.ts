import { Component, OnInit } from '@angular/core';
import { CompanyService } from '../company.service';
import { Icompany } from '../icompany';

@Component({
  selector: 'app-search-form',
  templateUrl: './search-form.component.html',
  styleUrls: ['./search-form.component.css']
})
export class SearchFormComponent implements OnInit {
  product: Icompany[];
  searchItem: any;
  temp: any;

  constructor(private productService:CompanyService ) {
    // this.productService.getCompany().subscribe(data=>this.product=data);
   }

  ngOnInit() {
    this.productService.getCompany().subscribe(data=>this.product=data)
  }

  searchItemFun() {
    this.searchItem=this.temp;
     }

}
