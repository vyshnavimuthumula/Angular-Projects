import { CompanyFilterPipe } from './company-filter.pipe';

describe('CompanyFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new CompanyFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
