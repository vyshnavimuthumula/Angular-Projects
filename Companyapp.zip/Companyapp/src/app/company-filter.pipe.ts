import { Pipe, PipeTransform } from '@angular/core';
import { Icompany } from './icompany';

@Pipe({
  name: 'companyFilter'
})
export class CompanyFilterPipe implements PipeTransform {

  transform(product:Icompany[],searchItem:string): any {
    searchItem=searchItem.toLowerCase(); 
 
    return product.filter(
      companyFilter=>(companyFilter.name.toLowerCase().startsWith(searchItem)||companyFilter.category.toLowerCase().startsWith(searchItem)));
 }
 
}

