import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Icompany } from './icompany';

@Injectable({
  providedIn: 'root'
})
export class CompanyService {
  product:Icompany[] ;

  constructor(private http:HttpClient) { }
  private _url:string="./assets/db.json";
  getCompany():Observable<Icompany[]>{
    return this.http.get<Icompany[]>(this._url);
  }
  getData(){
    return this.product;
  }
  setdata(productsData:Icompany[]){
    this.product = productsData;
  }
}
