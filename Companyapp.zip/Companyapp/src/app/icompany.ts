export interface Icompany {
        "id": number,
        "name": String,
        "price": number,
        "category": String
}
