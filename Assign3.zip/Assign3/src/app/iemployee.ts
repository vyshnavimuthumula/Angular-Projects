export interface Iemployee {
          "empId": number,
          "empName": String,
          "empSalary": number,
          "empDepartment": String
}

