import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  Employees;
  EmployeeService:any;
  updateId: number;
  updateName: String;
  updateSal: number;
  updateDep: String;
  updateres: any;
  constructor(private employeelist:EmployeeService) { }

  ngOnInit() {
    this.employeelist.getEmployee().subscribe(data=>this.Employees=data);
  }
  AddEmployee(id:number,name:String,salary:number,department:String){
    let uId = id;
    let uName = name;
    let uSalary = salary;
    let uDepartment = department;
    this.Employees.push({"empId":uId,"empName":uName,"empSalary":uSalary,"empDepartment":uDepartment});
  }
  update(emp){
    this.updateId=emp.empId;
    this.updateName=emp.empName;
    this.updateSal=emp.empSalary;
    this.updateDep=emp.empDepartment;
    this.updateres=emp;
    }
    updateEmployee(updateId:number,updateName:string,updateSal:number,updateDep:string){
    this.updateres.empId=updateId;
    this.updateres.empName=updateName;
    this.updateres.empSalary=updateSal;
    this.updateres.empDepartment=updateDep;
    }
    delete(emp){
    this.Employees.splice(this.Employees.indexOf(emp),1);
    }
    
    
   }

