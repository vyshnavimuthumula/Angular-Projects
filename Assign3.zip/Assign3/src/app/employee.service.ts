import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Iemployee } from './iemployee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private http:HttpClient) { }
    private _url :string ="./assets/employee.json";
  getEmployee():Observable<Iemployee[]>{
    return this.http.get<Iemployee[]>(this._url);
  }
  }
