import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'employeeFilter'
})
export class EmployeeFilterPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    return value.filter((data)=>data.empName.indexOf(args)!==-1);
  }

}
