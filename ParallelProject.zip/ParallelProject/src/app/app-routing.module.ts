import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NewUserComponent } from './new-user/new-user.component';
import { ExistingUserComponent } from './existing-user/existing-user.component';
import { CreateAccountComponent } from './create-account/create-account.component';
import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { MainDetailsComponent } from './main-details/main-details.component';
import { DepositComponent } from './deposit/deposit.component';
import { CreditComponent } from './credit/credit.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { PrintTransactionComponent } from './print-transaction/print-transaction.component';
export const routingcomponents = [NewUserComponent,ExistingUserComponent,CreateAccountComponent,ShowBalanceComponent,MainDetailsComponent,DepositComponent,CreditComponent]

const routes: Routes = [
  {
    path: 'newuser',
    component:NewUserComponent
  },
  {
    path: 'login',
    component: ExistingUserComponent
  },
  {
    path :'maindetails',
    component : MainDetailsComponent
  },
  {
    path: 'bank',
    component :CreateAccountComponent
  },
  {
    path:'showbalance',
    component : ShowBalanceComponent
  },
  {
    path :'deposit',
    component : DepositComponent
  },
  {
    path :'credit',
    component : CreditComponent
  },
  {
    path :'fundtransfer',
    component : FundTransferComponent
  },
  {
    path :'printtransaction',
    component : PrintTransactionComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
