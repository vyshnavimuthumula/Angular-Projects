import { Component, OnInit } from '@angular/core';
import { HttpClientService } from '../service/http-client.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {
  amount: number;
  constructor(private httpClientService:HttpClientService) { }
  ngOnInit() {
  }
 deposit(accountnum,amunt){
    this.httpClientService.depositMoney(accountnum,amunt).subscribe(data => {
    this.amount = data;
    this.httpClientService.setAccountNum(accountnum);
 });
}
}
