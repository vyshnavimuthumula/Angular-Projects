export class Bank {
    public accountnum: number;
    public name: string;
    public phonenum: string;
    public adharnum: string;
    public pin: number;
    public balance: number;
    // private username:string;
    // private password:string;
}