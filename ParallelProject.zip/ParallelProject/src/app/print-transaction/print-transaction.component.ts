import { Component, OnInit } from '@angular/core';
import { HttpClientService } from '../service/http-client.service';

@Component({
  selector: 'app-print-transaction',
  templateUrl: './print-transaction.component.html',
  styleUrls: ['./print-transaction.component.css']
})
export class PrintTransactionComponent implements OnInit {

  constructor(private httpClientService:HttpClientService) { }


 
 transactions: string[];
 
 ngOnInit() {
  this.httpClientService.getTransactionsByAccountNo().subscribe(data=> {
    this.transactions=data;
    console.log("this.transactions");
     });
     }
}