import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule,routingcomponents } from './app-routing.module';
import { AppComponent } from './app.component';
import {HttpClientModule} from '@angular/common/http';
import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { MainDetailsComponent } from './main-details/main-details.component'
import { NgModel } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { DepositComponent } from './deposit/deposit.component';
import { CreditComponent } from './credit/credit.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { PrintTransactionComponent } from './print-transaction/print-transaction.component';
@NgModule({
  declarations: [
    AppComponent,
   routingcomponents,
   ShowBalanceComponent,
   MainDetailsComponent,
   DepositComponent,
   CreditComponent,
   FundTransferComponent,
   PrintTransactionComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
