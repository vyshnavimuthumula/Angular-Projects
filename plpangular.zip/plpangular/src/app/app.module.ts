import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TrackingProductComponent } from './tracking-product/tracking-product.component';
import { TrackingDetailsComponent } from './tracking-details/tracking-details.component';

@NgModule({
  declarations: [
    AppComponent,
    TrackingProductComponent,
    TrackingDetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
