import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TrackingProductComponent } from './tracking-product.component';

describe('TrackingProductComponent', () => {
  let component: TrackingProductComponent;
  let fixture: ComponentFixture<TrackingProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TrackingProductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrackingProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
