import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tracking-product',
  templateUrl: './tracking-product.component.html',
  styleUrls: ['./tracking-product.component.css']
})
export class TrackingProductComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
