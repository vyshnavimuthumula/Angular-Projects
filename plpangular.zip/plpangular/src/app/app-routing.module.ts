import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TrackingDetailsComponent } from './tracking-details/tracking-details.component';


const routes: Routes = [
  {
    path:'trackingdetails',
    component:TrackingDetailsComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
