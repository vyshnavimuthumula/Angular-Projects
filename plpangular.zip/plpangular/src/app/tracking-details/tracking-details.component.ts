import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tracking-details',
  templateUrl: './tracking-details.component.html',
  styleUrls: ['./tracking-details.component.css']
})
export class TrackingDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
