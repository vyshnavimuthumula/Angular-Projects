import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { Observable } from 'rxjs';
import { Bank } from '../ibank';

@Injectable({
  providedIn: 'root'
})
export class HttpClientService {
  
  accountnum: any;
  //setBank: any;

  constructor(private httpClient:HttpClient) { }
  
  
  // public login(username,password):Observable<Bank>{
  //   return this.httpClient.get<Bank>("http://localhost:8086/login/username/password" +username+'/'+password);
  // }

  public createBankAccount(customerDetails) {
    return this.httpClient.post<Bank>("http://localhost:8086/bank", customerDetails);
  }

  showBalance(accountnum): Observable<number>
  {
    console.log(accountnum);
    return this.httpClient.get<number>("http://localhost:8086/showbalance/" + accountnum)
  }
  
  depositMoney(accountnum,amount): Observable<number>
  {
    console.log(accountnum);
    let url = 'http://localhost:8086/deposit/'+accountnum+'/'+amount;
    return this.httpClient.put<number>(url,"");
  }

  creditedMoney(accountnum,amount): Observable<number>
  {
    console.log(accountnum);
    let url = 'http://localhost:8086/withdraw/'+accountnum+'/'+amount;
    return this.httpClient.put<number>(url,"");
  }

  fundTransfer(accountnum1,accountnum2,amount): Observable<number>
  {
    let url = 'http://localhost:8086/fundtransfer/'+accountnum1+'/'+accountnum2+'/'+amount;
    return this.httpClient.put<number>(url,"");
  }
  // getTransactionsByAccountNo():Observable<number>{
  //   let url = 'http://localhost:8086/transactions/all/'+accountnum;
  //   return this.httpClient.put<number>(url,"");
  // }
  getTransactionsByAccountNo():Observable<string[]>{
    
    let url = 'http://localhost:8086/transactions/all/'+this.getAccountNum();   
      console.log(url);
      return this.httpClient.get<string[]>(url);
     }
     getAccountNum(){
      return this.accountnum;
     }
     
    setAccountNum(accountnum:number){
      this.accountnum=accountnum;
     }

    }
