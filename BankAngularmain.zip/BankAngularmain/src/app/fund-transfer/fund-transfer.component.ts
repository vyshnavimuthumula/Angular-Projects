import { Component, OnInit } from '@angular/core';
import { HttpClientService } from '../service/http-client.service';

@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit {

  amount: number;
  constructor(private httpClientService:HttpClientService) { }
  ngOnInit() {
  }
 fund(accountnum1,accountnum2,amt){
   this.httpClientService.fundTransfer(accountnum1,accountnum2,amt).subscribe(data => {
   this.amount = data;
 });
}

}
